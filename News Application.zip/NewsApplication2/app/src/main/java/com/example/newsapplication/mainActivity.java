package com.example.newsapplication;


import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
public  class mainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<News>> {
    public static final String Web = "https://content.guardianapis.com/search?";//
    private ListView newsListView;//
    private com.example.newsapplication.NewsAdapter newsAdapter;//
    private static final int newsID = 1;//
    private Object NewsAdapter;

    public Loader<List<News>> onCreateLoader(int id, Bundle args) {//
        Uri Uri = android.net.Uri.parse(Web);//
        Uri.Builder build = Uri.buildUpon();//

        build.appendQueryParameter("api-key", "test");//

        return new NewsMounted(this, build.toString());//
    }//
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        newsListView = (ListView) findViewById(R.id.listView);
        NewsAdapter = new NewsAdapter(this, new ArrayList<News>());
        newsListView.setAdapter(newsAdapter);
        newsListView.setEmptyView(findViewById(R.id.textView));
        newsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                News Item = newsAdapter.getItem(position);
                Uri ItemUri = Uri.parse(Item.getWeb());
                Intent websiteIntent = new Intent(Intent.ACTION_VIEW, ItemUri);
                startActivity(websiteIntent);
            }
        });

        if (networkUtils.networkAvailable(this)) {
            LoaderManager loadermanager = getSupportLoaderManager();
            loadermanager.initLoader(newsID, null, this);
        } else {
            TextView tvSplash = (TextView) findViewById(R.id.textView);
            tvSplash.setText(R.string.noInternet);

            ProgressBar progressBar = (ProgressBar) findViewById(R.id.loading);
            progressBar.setVisibility(View.GONE);
        }
    }

    public void onLoaderReset(Loader<List<News>> loader) {//
        newsAdapter.clear();//
    }//
    @Override
    public void onLoadFinished(Loader<List<News>> loader, List<News> newsList) {
        newsAdapter.clear();

        if (newsList != null && !newsList.isEmpty()) {//
            newsAdapter.addAll(newsList);//
        } else {//
            TextView tvSplash = (TextView) findViewById(R.id.textView);//
            tvSplash.setText(R.string.noResults);///
        }//
        ProgressBar progressBar = (ProgressBar) findViewById(R.id.loading);//
        progressBar.setVisibility(View.GONE);//
    }


}

