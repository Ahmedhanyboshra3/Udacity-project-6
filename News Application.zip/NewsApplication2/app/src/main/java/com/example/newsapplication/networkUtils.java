package com.example.newsapplication;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class networkUtils {
    public static Boolean networkAvailable(Context context) {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo NetworkInfo = connectivityManager.getActiveNetworkInfo();
        return NetworkInfo != null &&NetworkInfo.isConnectedOrConnecting();
    }
}
