package com.example.newsapplication;

import android.content.Context;
import android.renderscript.RenderScript;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class NewsAdapter extends ArrayAdapter<News>{
public NewsAdapter(Context con, ArrayList<News>NewsList){
    super(con,0,NewsList);
}
@Override
    public View getView(int Pos, View ConvertView, ViewGroup parent){
    if (ConvertView==null){
        LayoutInflater.from(getContext()).inflate(R.layout.list,parent,false);
    }
    TextView releasedDate= ConvertView.findViewById(R.id.releasedDate);
    TextView Title = ConvertView.findViewById(R.id.Title);
    News presentNews=getItem(Pos);
    releasedDate.setText(presentNews.getDate());
    Title.setText(presentNews.getTitle());
    return ConvertView;
}
}




