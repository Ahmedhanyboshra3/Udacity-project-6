package com.example.newsapplication;

public class News {
    String Date;
    String Title;
    String Author;
    String Web;
    public News(String Date, String Title, String Author, String Web){
        this.Date=Date;
        this.Title=Title;
        this.Author=Author;
        this.Web= Web;


    }

    public String getDate() {
        return Date;
    }

    public String getTitle() {
        return Title;
    }

    public String getAuthor() {
        return Author;
    }

    public String getWeb() {
        return Web;
    }
}
