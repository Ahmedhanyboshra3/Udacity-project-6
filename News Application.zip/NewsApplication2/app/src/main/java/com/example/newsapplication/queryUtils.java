package com.example.newsapplication;

import android.text.TextUtils;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class queryUtils {
    private static final String Tag=queryUtils.class.getSimpleName();
    private static Object JSONObject;

    public static List<News> fetchNewsData(String Web){
        try {
            Thread.sleep(100);

        }catch (InterruptedException exceptions){
            Log.e("getNewsData error", String.valueOf(exceptions));
        }
        URL webNews=createWeb(Web);//createWeb=create url
        String Responce=null;
        try {
            Responce=requestHttp(webNews);//requestHttp=makeHttprerquest
        }catch (IOException exceptions){
            Log.e(Tag,"getNewsData: Problem while geeting http request!",exceptions);

        }
        List<News> theNews=getNewsDataResponce(Responce);//getNewsDataResponce=extract news from josn
        return theNews;
    }

    private static List<News> getNewsDataResponce(String responce) {
        String Title;
        String Date;
        String webSource;
        if (TextUtils.isEmpty(responce)){
            return null;
        }
        List<News> theNews=new ArrayList<>();
        try {
            JSONObject basicResponce = new JSONObject(responce);
            JSONObject basicResult =basicResponce.getJSONObject("Responce");
            JSONArray presentlyNews=basicResult.getJSONArray("Results");
            int i;
            for(i=0; i<presentlyNews.length();i++){
                JSONObject=presentlyNews.getJSONObject(i);
                Title=presentlyNews.getString(Integer.parseInt("WebTitle"));
                webSource=presentlyNews.getString(Integer.parseInt("URL"));
                Date=presentlyNews.getString(Integer.parseInt("Released Date"));

            }
        }catch (JSONException jasonException){
            Log.e(Tag,"getNewsDataResponce Problem while extrcting the results",jasonException);
        }
        return theNews;
    }

    private static String requestHttp(URL webNews)throws IOException {
        String Responce="";
        if (webNews==null){
            return Responce;

        }
        HttpURLConnection webConnection = null;
        InputStream stream=null;
        try {
            webConnection=(HttpURLConnection) webNews.openConnection();
            webConnection.setReadTimeout(10000);
            webConnection.setConnectTimeout(15000);
            webConnection.setRequestMethod("get");
            webConnection.connect();
            if (webConnection.getResponseCode()==200){
                stream=webConnection.getInputStream();
                Responce=readStreamData(stream);

            }else {
                Log.e(Tag,"requestHttp: Error in the code"+webConnection.getResponseCode());

            }

        }catch (IOException ioexception){
            Log.e(Tag,"requestHttp: Couldn't get data",ioexception);

        }finally {
            if (webConnection!=null) {
                webConnection.disconnect();

            }
            if (stream!=null){
                stream.close();
            }
        }
        return Responce;
    }

    private static String readStreamData(InputStream stream) throws IOException {
        StringBuilder builder=new StringBuilder();
        if (stream!=null){
            InputStreamReader streamReader= new InputStreamReader(stream, Charset.forName("UTF-8"));
            BufferedReader bufferedReader=new BufferedReader(streamReader);
            String Line=bufferedReader.readLine();
            while (Line!=null){
                builder.append(Line);
                Line=bufferedReader.readLine();
            }
        }
        return builder.toString();
    }

    private static URL createWeb(String web) {
        URL Web=null;
        try {
            web= String.valueOf(new URL(web));

        }catch (MalformedURLException malFormedException){
            Log.e(Tag,"problem with getting web",malFormedException);
        }
        return Web;
    }
}
