package com.example.newsapplication;

import android.content.Context;
import android.util.Log;
import androidx.loader.content.AsyncTaskLoader;
import java.util.List;
import static android.content.ContentValues.TAG;

public class NewsMounted extends AsyncTaskLoader<List<News>> {
    private String web;
    protected void onStartLoading() {
        forceLoad();
    }
    public List<News> loadInBackground() {
        if(web == null) return null;

        List<News> newsList = queryUtils.fetchNewsData(web);
        return newsList;
    }
    public NewsMounted(Context context, String Web) {
        super(context);
        Log.i(TAG, "newsMounted: "+ Web);
        web = Web;
    }




}
